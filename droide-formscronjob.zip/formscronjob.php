<?php 
/**
 * @package     mod_droideforms.Plugin
 * @subpackage  droide-fromscronjob
 * @copyright   Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author 		André Luiz Pereira <[<and4563@gmail.com>]>
 */

defined('_JEXEC') or die ();



class plgSystemFormscronjob extends JPlugin{

    public function __construct(&$subject, $config)
    {

        parent::__construct($subject, $config);

    }

    /**
     * Organiza os elementos registrados no admin de forma amigavel para tratamento
    * @param  array $parans_bruto - array com os atributos vindos do repeteable
    * @return array array bruto tratado
    * @author André Luiz Pereira <andre@next4.com.br>
    */
    private function organizeArray($parans_bruto)
    {
        
        $total = count($parans_bruto['module_id']);

        $resultado = [];

        for ($i=0; $i <$total; $i++)
        { 
            $resultado[] = [
                'module_id'=>$parans_bruto['module_id'][$i],
                'emails'=>$parans_bruto['emails'][$i],
                'assunto'=>$parans_bruto['assunto'][$i],
                'periodo_envio'=>$parans_bruto['periodo_envio'][$i],
            ];
        }

        return $resultado;
    }


    public function onAfterRoute()
    {

        $key = $this->params->get('key','dsfjdwojnsndfpsjdf_4654545446151');
        $jinput = JFactory::getApplication()->input;
       $get = $jinput->get('cron_droideforms', 0, 'STRING');

        if($get == $key)
        {

            $params_bruto = json_decode($this->params->get('addtable',0),true);

            $parans = $this->organizeArray($params_bruto);

            echo "<pre>";
            print_r($parans);
            

        }else{
            echo "chave inválida";
        }

        exit;
    }




}