# droide-formscronjob
Destinado para envio de relatórios do forms pelo cron
